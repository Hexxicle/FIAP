import java.util.Scanner;

public class Exercicio8 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int  numero, dezena;
		
		System.out.println("Digite um numero com 3 digitos: ");
		numero = in.nextInt();
		dezena = (numero % 100) / 10;
		System.out.println("A dezena do seu numero é: " + dezena);
	}

}
