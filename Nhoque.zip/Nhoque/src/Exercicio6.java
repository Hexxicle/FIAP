import java.util.Scanner;

public class Exercicio6 {

	public static void main(String[] args) {
	
		Scanner in = new Scanner(System.in);
		double x, y, resultado;
		
		System.out.print("Digite o número que será usado na equação: ");
		x = in.nextDouble();
		y = Math.sqrt(x - (1 / 2));
		resultado = Math.cbrt(y);
		System.out.print("O resultado da sua equação é: " + String.format("%.2f", resultado));
		
		in.close();
		
	}

}
