import java.util.Scanner;

public class Exercicio10 {
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int  codigoBinario;
		
		System.out.print("Digite em classe binária o numero a ser convertido: ");
		codigoBinario = in.nextInt();
		
		int unidade = (codigoBinario % 10) * (int)(Math.pow(2, 0));
		int dezena = ((codigoBinario / 100) % 10) * (int)(Math.pow(2, 1));
		int centena = (codigoBinario % 100) / 10 * (int)(Math.pow(2, 2));
		int milhar = (codigoBinario / 1000) * (int)(Math.pow(2, 3));
		
		System.out.println(unidade);
		System.out.println(dezena);
		System.out.println(centena);
		System.out.println(milhar);
		
		codigoBinario = unidade + dezena + centena + milhar;
		
		System.out.println("Seu número na Base 10 é: " + codigoBinario);
		
		in.close();
	}

}
