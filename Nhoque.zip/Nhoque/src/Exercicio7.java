import java.util.Scanner;

public class Exercicio7 {
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		double x, resultado;
		
		System.out.print("Digite o número que será usado na equação: ");
		x = in.nextDouble();
		resultado = Math.sqrt(1 + (Math.pow(x, 4) - 1 / 2 * Math.pow(x, 2)) - Math.pow(x, 2) / 2);
		System.out.print("O resultado da sua equação é " + String.format("%.2f", resultado));
		
		in.close();
	}

}
