import java.util.Scanner;

public class Exercicio9 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numero, unidade, dezena, centena;
		
		System.out.print("Digite o numero a ser invertido: ");
		numero = in.nextInt();
		centena = numero / 100;
		dezena = numero % 100 / 10;
		unidade = numero % 10;
		
		numero = (unidade * 100)  + (dezena * 10) + centena;
		
		System.out.print("O seu numero invertido é " + numero);
		
		in.close();
	}

}
