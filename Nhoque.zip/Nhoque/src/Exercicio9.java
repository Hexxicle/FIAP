import java.util.Scanner;

public class Exercicio9 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int valor, dezena;
		
		System.out.print("Valor (100 - 999):");
		valor = in.nextInt();
		
		dezena = valor % 100 / 10;
		System.out.println("Seu numero ao contrario é: " + dezena);

	}

}
